
import './App.css';
import Navbar from './compnents/Navbar';

function App() {
  return (
    <div className="App">
         <Navbar/>
         <hr id='hr'/>
    </div>
  );
}

export default App;
